#ifndef __terminal_h__
#define __terminal_h__
  
  void goToPos(int x, int y);
  void cls(void);
  void init(void);
  void putString(const char *buffer);
  
#endif
